myName="Thomas";
function writ(x)
{
	if (answer == null) 
	{	alert('you haven\'t entered anything') ; 	}
	else 
	{	alert(answer+' is your favourite color') ;	}
 
}

document.write("Hello <i>"+myName+" </i>");
answer = prompt("What is your favorite color?");

writ(answer)
alert('Under HTML!')
